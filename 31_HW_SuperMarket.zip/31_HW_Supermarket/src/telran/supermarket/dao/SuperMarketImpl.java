package telran.supermarket.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import telran.supermarket.model.Product;

public class SuperMarketImpl implements SuperMarket {
	Collection<Product> products;

	public SuperMarketImpl() {
		products = new ArrayList<Product>();
	}

	@Override
	public Iterator<Product> iterator() {
		return products.iterator();
	}

	@Override
	public boolean addProduct(Product product) {
		if (product == null || findByBarCode(product.getBarCode()) != null) {
			return false;
		}
		products.add(product);
		return false;
	}

	@Override
	public Product removeProduct(long barCode) {
		for (Product item : products) {
			Product a = (Product) item;
			if (a.getBarCode() == barCode) {
				products.remove(a);
				return a;
			}
		}
		return null;
	}

	@Override
	public Product findByBarCode(long barCode) {
		for (Product item : products) {
			Product a = (Product) item;
			if (a.getBarCode() == barCode) {
				return a;
			}
		}
		return null;
	}

	@Override
	public Iterable<Product> findByCategory(String category) {
		Collection<Product> tempList = new ArrayList<Product>(products.size());
		for (Product item : products) {
			Product a = (Product) item;
			if (a.getCategory().equals(category)) {
				tempList.add(item);
			}
		}
		return (Iterable<Product>) tempList;
	}

	@Override
	public Iterable<Product> findByBrand(String brand) {
		Collection<Product> tempList = new ArrayList<Product>(products.size());
		for (Product item : products) {
			Product a = (Product) item;
			if (a.getBrand().equals(brand)) {
				tempList.add(item);
			}
		}
		return (Iterable<Product>) tempList;
	}

	@Override
	public Iterable<Product> findProductWithExpDate() {
		Collection<Product> tempList = new ArrayList<Product>(products.size());
		for (Product item : products) {
			Product a = (Product) item;
			if (a.getExpDate().isBefore(LocalDate.now())) {
				tempList.add(item);
			}
		}
		return (Iterable<Product>) tempList;
	}

	@Override
	public int skuQuantity() {
		return products.size();
	}

}
