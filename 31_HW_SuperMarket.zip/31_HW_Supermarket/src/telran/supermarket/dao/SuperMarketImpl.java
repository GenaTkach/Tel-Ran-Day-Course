package telran.supermarket.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import telran.supermarket.model.Product;

public class SuperMarketImpl<T> implements SuperMarket<T> {
	private static final int MAX_ARRAY_SIZE = Integer.MAX_VALUE - 8;
	Collection<T> products;
	int capacity;

	public SuperMarketImpl(int capacity) {
		products = new ArrayList<T>();
		this.capacity = capacity;
	}

	@Override
	public Iterator<T> iterator() {
		return products.iterator();
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean addProduct(Product product) {
		if (product == null || findByBarCode(product.getBarCode()) != null) {
			return false;
		}
		ensureCapacity();
		products.add((T) product);
		return false;
	}

	private void ensureCapacity() {
		if (products.size() == MAX_ARRAY_SIZE) {
			throw new OutOfMemoryError();
		}
		if (products.size() == capacity) {
			int newCapacity = products.size() + products.size() / 2 + 1;
			if (newCapacity < 0 || newCapacity > MAX_ARRAY_SIZE) {
				newCapacity = MAX_ARRAY_SIZE;
			}
			Collection<T> productsNew = new ArrayList<T>(products.size() * 2);
			productsNew.addAll(products);
			products = productsNew;
		}
	}

	@Override
	public Product removeProduct(long barCode) {
		for (T item : products) {
			Product a = (Product) item;
			if (a.getBarCode() == barCode) {
				products.remove(a);
				return a;
			}
		}
		return null;
	}

	@Override
	public Product findByBarCode(long barCode) {
		for (T item : products) {
			Product a = (Product) item;
			if (a.getBarCode() == barCode) {
				return a;
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterable<Product> findByCategory(String category) {
		Collection<T> tempList = new ArrayList<T>(products.size());
		for (T item : products) {
			Product a = (Product) item;
			if (a.getCategory().equals(category)) {
				tempList.add(item);
			}
		}
		return (Iterable<Product>) tempList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterable<Product> findByBrand(String brand) {
		Collection<T> tempList = new ArrayList<T>(products.size());
		for (T item : products) {
			Product a = (Product) item;
			if (a.getBrand().equals(brand)) {
				tempList.add(item);
			}
		}
		return (Iterable<Product>) tempList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterable<Product> findProductWithExpDate() {
		Collection<T> tempList = new ArrayList<T>(products.size());
		for (T item : products) {
			Product a = (Product) item;
			if (a.getExpDate().isBefore(LocalDate.now())) {
				tempList.add(item);
			}
		}
		return (Iterable<Product>) tempList;
	}

	@Override
	public int skuQuantity() {
		return products.size();
	}

}
