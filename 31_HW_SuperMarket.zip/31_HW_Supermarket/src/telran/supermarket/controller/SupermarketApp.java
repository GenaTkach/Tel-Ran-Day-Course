package telran.supermarket.controller;

import java.time.LocalDate;

import telran.supermarket.dao.SuperMarketImpl;
import telran.supermarket.model.Product;

public class SupermarketApp {

	public static <T> void main(String[] args) {
		SuperMarketImpl<T> market = new SuperMarketImpl<T>(10);
		Product cheese = new Product(1, "Cheese", "Milk", "OPA", 20.0, LocalDate.of(2022, 8, 14));
		Product pepper = new Product(2, "Pepper", "Veg", "UAR", 30.0, LocalDate.of(1999, 2, 24));
		Product soy = new Product(3, "Soy", "Milk", "OPA", 20.0, LocalDate.of(2022, 9, 14));
		Product orange = new Product(4, "Orange", "Fruit", "ISR", 20.0, LocalDate.of(1999, 9, 14));
		
		market.addProduct(cheese);
		market.addProduct(pepper);
		market.addProduct(soy);
		market.addProduct(soy);
		market.addProduct(orange);
		
		System.out.println("================Print all products in market=================");
		for (T item : market) {
			System.out.println(item);
		}
		
		System.out.println("================SKU before remove=================");
		int x = market.skuQuantity();
		System.out.println("SKU now = " + x);
		
		System.out.println("================SKU after remove=================");
		market.removeProduct(3);
		x = market.skuQuantity();
		System.out.println("SKU after remove = " + x);
		
		System.out.println("================Print all expired products=================");
		System.out.print(market.findProductWithExpDate());
	}

}
