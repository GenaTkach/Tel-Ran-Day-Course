package telran.food.model;

import telran.product.model.Product;

public class Food extends Product {
	protected boolean kosher;
	private String expDate;

	public Food(int barcode, String name, double price, boolean kosher, String expDate) {
		super(barcode, name, price);
		this.kosher = kosher;
		this.expDate = expDate;
	}

	public void display() {
		super.display();
		System.out.print(", Is it Kosher?:" + kosher);
		System.out.print(", Expiration date:" + expDate);
	}

	public boolean isKosher() {
		return kosher;
	}

	public void setKosher(boolean kosher) {
		this.kosher = kosher;
	}

	public String getExpDate() {
		return expDate;
	}

	public void setExpDate(String expDate) {
		this.expDate = expDate;
	}

}
