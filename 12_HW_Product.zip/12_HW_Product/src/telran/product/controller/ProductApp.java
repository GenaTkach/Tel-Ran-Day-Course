package telran.product.controller;

import telran.food.model.Food;
import telran.food.model.MeatFood;
import telran.food.model.MilkFood;
import telran.product.model.Product;

public class ProductApp {

	public static void main(String[] args) {
		Product[] food = new Product[6];
		food[0] = new MeatFood(1, "Chiken breast", 30, true, "04.06.22", "Chiken");
		food[1] = new MeatFood(2, "Bacon", 55, false, "05.06.22", "Pork");
		food[2] = new MilkFood(3, "Cream", 8.7, true, "23.06.22", "Cow milk", 15);
		food[3] = new MilkFood(3, "Cheese", 9, true, "10.06.22", "Goat milk", 45);
		food[4] = new Food(5, "Orange", 6, true, "23.08.22");
		food[5] = new Product(6, "Book", 120);

		for (int i = 0; i < food.length; i++) {
			food[i].display();
			System.out.println();
		}

		System.out.println("============================================================");
		double res = priceOfKosher(food);
		System.out.println(res);
	}

	public static double priceOfKosher(Product[] food) {
		double res = 0;
		for (int i = 0; i < food.length; i++) {
			if (food[i] instanceof Food) {
				Food temp = (Food) food[i];
				if (temp.isKosher()) {
					res += temp.getPrice();
				}
			}
		}
		return res;
	}
}