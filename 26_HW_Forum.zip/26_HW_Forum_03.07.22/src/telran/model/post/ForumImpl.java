package telran.model.post;

import java.time.LocalDate;
import java.util.Arrays;

public class ForumImpl implements Forum {
//	Post[] posts = new Post[4];
//	int size = 4;
	Post[] posts;
	int size;

	public ForumImpl() {
		posts = new Post[0];
//		posts[0] = new Post("Sam", 1, "title1", "content1");
//		posts[1] = new Post("Sam", 2, "title2", "content2");
//		posts[2] = new Post("Axe", 3, "title3", "content3");
//		posts[3] = new Post("Axe", 4, "title4", "content4");
	}

	@Override
	public boolean addPost(Post post) {
		if (post == null || getPostById(post.getPostId()) != null) {
			return false;
		}
		Post[] newPosts = Arrays.copyOf(posts, posts.length + 1);
		newPosts[size++] = post;
		posts = newPosts;
		return true;
	}

	@Override
	public boolean removePost(int postId) {
		for (int i = 0; i < size; i++) {
			if (posts[i].getPostId() == postId) {
				Post[] newArr = new Post[posts.length - 1];
				size--;
				System.arraycopy(posts, 0, newArr, 0, size - i);
				System.arraycopy(posts, i, newArr, i, size - i);
				posts = newArr;
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean updatePost(int postId, String newContent) {
		for (int i = 0; i < size; i++) {
			if (posts[i].getPostId() == postId) {
				posts[i].setContent(newContent);
				return true;
			}
		}
		return false;
	}

	@Override
	public Post getPostById(int postId) {
		Post pattern = new Post(null, postId, null, null);
		for (int i = 0; i < size; i++) {
			if (posts[i].equals(pattern)) {
				return posts[i];
			}
		}
		return null;
	}

	@Override
	public Post[] getPostsByAuthor(String author) {
		Post[] newArr = new Post[size];
		int j = 0;
		for (int i = 0; i < size; i++) {
			if(posts[i].getAuthor().equals(author)) {
				newArr[j++] = posts[i];
			}
		}
		return Arrays.copyOf(newArr, j);
	}

	@Override
	public Post[] getPostsByAuthor(String author, LocalDate dateFrom, LocalDate dateTo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		return size;
	}

}
