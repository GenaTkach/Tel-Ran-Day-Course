package telran.model.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import telran.model.post.Forum;
import telran.model.post.ForumImpl;
import telran.model.post.Post;

class ForumImplTest {
	Forum forum;
	Post[] posts;
	

	@BeforeEach
	void setUp() throws Exception {
		forum = new ForumImpl();
		posts[0] = new Post("Sam", 1, "title", "content");
		posts[1] = new Post("Sam", 2, "title", "content");
		posts[2] = new Post("Sam", 3, "title", "content");
		for (int i = 0; i < posts.length; i++) {
			forum.addPost(posts[i]);
		}
		
	}

	@Test
	void testAddPost() {
		assertTrue(forum.addPost(new Post("Sam", 5, "title2", "content2")));
//		assertFalse(forum.addPost(new Post("Sam", 1, "title2", "content2")));
//		assertFalse(forum.addPost(new Post("Sam", 2, "title2", "content2")));
//		assertFalse(forum.addPost(new Post("Sam", 3, "title2", "content2")));
//		assertFalse(forum.addPost(new Post("Sam", 4, "title2", "content2")));
//		assertTrue(forum.addPost(new Post("Sam", 5, "title2", "content2")));
//		assertEquals(5, forum.size());
//		assertFalse(forum.addPost(new Post("Sam", 5, "title2", "content2")));
	}

//	@Test
//	void testRemovePost() {
//		assertTrue(forum.removePost(1));
//		assertEquals(3, forum.size());
//		assertFalse(forum.removePost(10));
//	}
//
//	@Test
//	void testUpdatePost() {
//		assertTrue(forum.updatePost(1, "newContent"));
//		assertFalse(forum.updatePost(5, "newContent"));
//	}
//
	@Test
	void testGetPostById() {
		assertTrue(forum.addPost(new Post("Sam", 5, "title2", "content2")));
		assertEquals(posts[0], forum.getPostById(5));
	}
//
//	@Test
//	void testGetPostsByAuthor() {
//		Post[] actual = forum.getPostsByAuthor("Sam");
//		Post[] expected = {posts[0], posts[1]};
//		assertArrayEquals(expected, actual);
//	}
//
//	@Test
//	void testGetPostsByAuthor1() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testSize() {
//		assertEquals(4, forum.size());
//	}

}
