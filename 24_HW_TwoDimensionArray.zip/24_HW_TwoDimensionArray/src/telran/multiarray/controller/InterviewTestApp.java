package telran.multiarray.controller;

public class InterviewTestApp {

	public static void main(String[] args) {
		int[][] bigArray = new int[10_000][10_000];
		long t1 = System.currentTimeMillis();
		fillArray(bigArray);
		long t2 = System.currentTimeMillis();
		System.out.println(t2 - t1);
		
		t1 = System.currentTimeMillis();
		fillArrayOptimised(bigArray);
		t2 = System.currentTimeMillis();
		System.out.println(t2 - t1);
		
	}

	private static void fillArray(int[][] bigArray) {
		for (int i = 0; i < bigArray.length; i++) {
			for (int j = 0; j < bigArray[i].length; j++) {
				bigArray[i][j] = i * j;
			}
		}
	}

	private static void fillArrayOptimised(int[][] bigArray) {
		for (int i = 0; i < bigArray.length; i++) {
			bigArray[i][i] = i * i;
			for (int j = i; j < bigArray[i].length; j++) {
				bigArray[i][j] = bigArray[j][i] = i * j;
			}
		}
	}
	
}