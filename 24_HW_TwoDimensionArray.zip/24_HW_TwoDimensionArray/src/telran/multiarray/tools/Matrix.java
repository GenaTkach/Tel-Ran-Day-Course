package telran.multiarray.tools;

public class Matrix {
	public static int sum(int[][] matrix) {
		int count = 0;
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				count += matrix[i][j];
			}
		}
		return count;
	}

	public static int[][] transp(int[][] matrix) {
		// TODO int[1][3] -> int[3][1]
//		int[][] matrix1 = { { 1, 2, 3 } }; // 1x3
//		int[][] matrix2 = { { 1 }, { 2 }, { 3 } }; // 3x1

		// Finding number of rows for future array
		int col = matrix.length;
		int row = 0;
		for (int i = 0; i < 1; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				row++;
			}
		}

		// Creating new 2D array and filling it
		int[][] newArr = new int[row][col]; // row -> 3, col -> 1
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < row; j++) {
				newArr[j][i] = matrix[i][j];
			}
		}
		return newArr;
	}

	public static int[][] multiply(int[][] matrix, int[][] matrix2) {
		// Check that arrays have the same lenght
		int matrixCol = 0;
		for (int i = 0; i < 1; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				matrixCol++;
			}
		}

		if (matrixCol == matrix2.length) {
			// Finding number of columns for matrix2
			int matrix2Col = 0;
			for (int i = 0; i < 1; i++) {
				for (int j = 0; j < matrix2[i].length; j++) {
					matrix2Col++;
				}
			}
			// Create new array
			int[][] newArr = new int[matrix.length][matrix2Col];
			// Outer loop
			for (int k = 0; k < newArr.length; k++) {
				// Inner loop
				int counter = 0;
				for (int i = 0; i < matrix.length; i++) {
					for (int j = 0; j < matrix2.length; j++) {
						counter += matrix[i][j] * matrix2[j][k];
					}
					newArr[k][i] = counter;
					counter = 0;
				}
			}
			return newArr;
		}
		// Return null if can't pass the checkpost
		return null;
	}
}
