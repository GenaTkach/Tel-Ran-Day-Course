package telran.citizens.dao;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

import telran.citizens.interfaces.Citizens;
import telran.citizens.model.Person;

public class CitizensImpl implements Citizens {
	private TreeSet<Person> idSet;
	private TreeSet<Person> lastNameSet;
	private TreeSet<Person> ageSet;

	// Компараторы на возраст и фамилию.
	// Если фамлиии равны, то есть res = 0, то сравниваем по id.
	// Тоже самое и с возрастом.
	private static Comparator<Person> lastNameComparator;
	private static Comparator<Person> ageComparator;

	// Статик - блок
	static {
		lastNameComparator = (p1, p2) -> {
			int res = p1.getLastName().compareTo(p2.getLastName());
			return res != 0 ? res : Integer.compare(p1.getId(), p2.getId());
		};
		ageComparator = (p1, p2) -> {
			int res = Integer.compare(p1.getAge(), p2.getAge());
			return res != 0 ? res : Integer.compare(p1.getId(), p2.getId());
		};
	};

	public CitizensImpl() {
		idSet = new TreeSet<>();
		lastNameSet = new TreeSet<>(lastNameComparator);
		ageSet = new TreeSet<>(ageComparator);
	}

	public CitizensImpl(List<Person> citizens) {
		// Вызов дефолтного класса и инициализация 3 классов
		this();
		// Вызов метода add, который будет имплементирован позже
		citizens.forEach(p -> add(p));
	}

	// Конструктор принимающий массив остаточных элементов
	public CitizensImpl(Person... citizens) {
		// Вызов дефолтного класса и инициализация 3 классов
		this();
		for (int i = 0; i < citizens.length; i++) {
			add(citizens[i]);
		}
	}

	// O(log(n))
	@Override
	public boolean add(Person person) {
		return person != null && idSet.add(person) && lastNameSet.add(person) && ageSet.add(person);
	}

	// O(log(n))
	@Override
	public boolean remove(int id) {
//		Person pattern = new Person(id, null, null, null);
		Person pattern = find(id);
		return pattern != null && idSet.remove(pattern) && lastNameSet.remove(pattern) && ageSet.remove(pattern);
	}

	// O(log(n))
	@Override
	public Person find(int id) {
		Person pattern = new Person(id, null, null, null);
		Person person = idSet.ceiling(pattern);
		return pattern.equals(person) ? person : null;
	}

	// O(log(n))
	@Override
	public Iterable<Person> find(int minAge, int maxAge) {
		Person patternMinAge = new Person(Integer.MIN_VALUE, null, null, LocalDate.now().minusYears(minAge));
		Person patternMaxAge = new Person(Integer.MAX_VALUE, null, null, LocalDate.now().minusYears(maxAge));

		return ageSet.subSet(patternMinAge, true, patternMaxAge, true);
	}

	@Override
	public Iterable<Person> find(String lastName) {
		Person patternMin = new Person(Integer.MIN_VALUE, null, lastName, null);
		Person patternMax = new Person(Integer.MAX_VALUE, null, lastName, null);
		return lastNameSet.subSet(patternMin, patternMax);

	}

	// O(1)
	@Override
	public Iterable<Person> getAllPersonSortedById() {
		return idSet;
	}

	// O(1)
	@Override
	public Iterable<Person> getAllPersonSortedByLastName() {
		return lastNameSet;
	}

	// O(1)
	@Override
	public Iterable<Person> getAllPersonSortedByAge() {
		return ageSet;
	}

	// O(1)
	@Override
	public int size() {
		return idSet.size();
	}

}
