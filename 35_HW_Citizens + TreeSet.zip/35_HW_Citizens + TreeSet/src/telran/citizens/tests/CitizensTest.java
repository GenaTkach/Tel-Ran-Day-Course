package telran.citizens.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import telran.citizens.dao.CitizensImpl;
import telran.citizens.interfaces.Citizens;
import telran.citizens.model.Person;

class CitizensTest {
	Citizens citizens;

	@BeforeEach
	void setUp() throws Exception {
//		citizens = new CitizensImpl(
//				Arrays.asList(new Person(1, "Peter", "Jackson", LocalDate.now().minusYears(23)), new Person(2, "John", "Smith", LocalDate.now().minusYears(20)),
//						new Person(3, "Mary", "Jackson", LocalDate.now().minusYears(20)), new Person(4, "Tigran", "Petrosian", LocalDate.now().minusYears(25))));
		citizens = new CitizensImpl(
				new Person(1, "Peter", "Jackson", LocalDate.now().minusYears(23)),
				new Person(2, "John", "Smith", LocalDate.now().minusYears(20)),
				new Person(3, "Mary", "Jackson", LocalDate.now().minusYears(20)),
				new Person(4, "Tigran", "Petrosian", LocalDate.now().minusYears(25))
		);
	}

	@Test
	void testCitizensImplListOfPerson() {
		citizens = new CitizensImpl(List.of(new Person(1, "Peter", "Jackson", LocalDate.now().minusYears(23)),
				new Person(1, "Peter", "Jackson", LocalDate.now().minusYears(23))));
		assertEquals(1, citizens.size());
	}

	@Test
	void testAdd() {
		assertFalse(citizens.add(null));
		assertFalse(citizens.add(new Person(1, "Peter", "Jackson", LocalDate.now().minusYears(23))));
		assertEquals(4, citizens.size());
		assertTrue(citizens.add(new Person(5, "Peter", "Jackson", LocalDate.now().minusYears(23))));
		assertEquals(5, citizens.size());
	}

	@Test
	void testRemove() {
		assertFalse(citizens.remove(5));
		assertEquals(4, citizens.size());
		assertTrue(citizens.remove(1));
		assertEquals(3, citizens.size());

	}

	@Test
	void testFindInt() {
		Person temp = citizens.find(1);
		assertEquals(1, temp.getId());
		assertEquals("Peter", temp.getFirstName());
		assertEquals("Jackson", temp.getLastName());
		assertNull(citizens.find(10));
	}

	@Test
	void testFindIntInt() {
		Iterable<Person> temp = citizens.find(20, 23);
		Iterable<Person> expected = Arrays.asList(new Person(1, "Peter", "Jackson", LocalDate.now().minusYears(23)),
				new Person(2, "John", "Smith", LocalDate.now().minusYears(20)),
				new Person(3, "Mary", "Jackson", LocalDate.now().minusYears(20)));
		ArrayList<Person> actual = new ArrayList<Person>();
//		temp.forEach(p -> actual.add(p));
		for (Person person : temp) {
			actual.add(person);
		}
		Collections.sort(actual);
		assertIterableEquals(expected, actual);
	}

	@Test
	void testFindString() {
		Iterable<Person> temp = citizens.find("Jackson");
		Iterable<Person> expected = Arrays.asList(new Person(1, "Peter", "Jackson", LocalDate.now().minusYears(23)),
				new Person(3, "Mary", "Jackson", LocalDate.now().minusYears(20)));
		ArrayList<Person> actual = new ArrayList<>();
		temp.forEach(p -> actual.add(p));
		Collections.sort(actual);
		assertIterableEquals(expected, actual);
	}

	@Test
	void testGetAllPersonSortedById() {
		Iterable<Person> temp = citizens.getAllPersonSortedById();
		int id = 0;
		for (Person person : temp) {
			assertTrue(person.getId() > id);
			id = person.getId();
		}
	}

	@Test
	void testGetAllPersonSortedByLastName() {
		Iterable<Person> temp = citizens.getAllPersonSortedByLastName();
		String lastName = "";
		for (Person person : temp) {
			assertTrue(person.getLastName().compareTo(lastName) >= 0);
			lastName = person.getLastName();
		}
	}
	@Test
	void testGetAllPersonSortedByAge() {
		Iterable<Person> temp = citizens.getAllPersonSortedByAge();
		Integer age = null;
		for (Person person : temp) {
			if (age != null) {
				assertTrue(person.getAge() >= age);
			}
			age = person.getAge();
		}
	}

	@Test
	void testSize() {
		assertEquals(4, citizens.size());
	}

}
