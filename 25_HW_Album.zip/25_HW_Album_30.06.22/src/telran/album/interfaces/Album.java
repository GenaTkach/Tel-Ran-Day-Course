package telran.album.interfaces;

import java.time.LocalDate;
import java.time.LocalDateTime;

import telran.album.model.Photo;

public interface Album {
	boolean addPhoto(Photo photo);

	boolean removePhoto(int photoId, int albumId);

	boolean updatePhoto(int photoId, int albumId, String url);

	Photo getPhotoFromAlbum(int photoId, int albumId);

	Photo[] getAllPhotoFromAlbum(int albumId);

	Photo[] getPhotoBetweenDate(LocalDate localDateTime, LocalDate localDateTime2);

	int size();
}
