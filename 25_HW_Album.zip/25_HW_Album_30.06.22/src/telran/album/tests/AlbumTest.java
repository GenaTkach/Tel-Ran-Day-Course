package telran.album.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Comparator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import telran.album.dao.AlbumImpl;
import telran.album.interfaces.Album;
import telran.album.model.Photo;

class AlbumTest {
	Album album;
	Photo[] photos;

	@BeforeEach
	void setUp() throws Exception {
		album = new AlbumImpl(6);
		photos = new Photo[5];
		photos[0] = new Photo(1, 100, "sea", "https://www.sea.com", LocalDateTime.now());
		photos[1] = new Photo(1, 200, "surfing", "https://www.surf.com", LocalDateTime.of(2000, 8, 12, 10, 23));
		photos[2] = new Photo(2, 100, "family", "https://www.fam.com", LocalDateTime.of(1965, 1, 28, 10, 00));
		photos[3] = new Photo(2, 200, "dogs", "https://www.dogs.com", LocalDateTime.of(1987, 3, 18, 18, 00));
		photos[4] = new Photo(2, 300, "New Year", "https://www.NY.com", LocalDateTime.of(1993, 1, 1, 00, 00));
		for (int i = 0; i < photos.length; i++) {
			album.addPhoto(photos[i]);
		}
		Arrays.sort(photos);
		
		//Order after sort
		/*
		 *photos[0] = new Photo(2, 100, "family", "https://www.fam.com", LocalDateTime.of(1965, 1, 28, 10, 00));
		 *photos[1] = new Photo(2, 200, "dogs", "https://www.dogs.com", LocalDateTime.of(1987, 3, 18, 18, 00));
		 *photos[2] = new Photo(2, 300, "New Year", "https://www.NY.com", LocalDateTime.of(1993, 1, 1, 00, 00));
		 *photos[3] = new Photo(1, 200, "surfing", "https://www.surf.com", LocalDateTime.of(2000, 8, 12, 10, 23));
		 *photos[4] = new Photo(1, 100, "sea", "https://www.sea.com", LocalDateTime.now());
		 */
	}

	@Test
	void testAddPhoto() {
		assertEquals(5, album.size());
		assertFalse(album.addPhoto(new Photo(1, 100, "sea", "https://www.sea.com", LocalDateTime.now())));
		assertTrue(album.addPhoto(new Photo(1, 300, "bar", "https://www.bar.com", LocalDateTime.now())));
	}

	@Test
	void testRemovePhoto() {
		assertTrue(album.removePhoto(100, 2));
		assertNull(album.getPhotoFromAlbum(100, 1));
	}

	@Test
	void testUpdatePhoto() {
		assertTrue(album.updatePhoto(100, 1, "ocean"));
		assertFalse(album.updatePhoto(300, 1, "ocean"));

	}

	@Test
	void testGetPhotoFromAlbum() {
		assertEquals(photos[4], album.getPhotoFromAlbum(100, 1));
	}

	@Test
	void testGetAllPhotoFromAlbum() {
		Photo[] expected = { photos[4], photos[3], };
		assertArrayEquals(expected, album.getAllPhotoFromAlbum(1));
		Photo[] expected1 = { photos[0], photos[1], photos[2] };
		assertArrayEquals(expected1, album.getAllPhotoFromAlbum(2));
		album.removePhoto(200, 1);
		Photo[] expected2={photos[3]};
		assertArrayEquals(expected2, album.getAllPhotoFromAlbum(1));

	}

	@Test
	void testGetPhotoBetweenDate() {
		Photo[] expected = { photos[0], photos[1], };
		Photo[] actual = album.getPhotoBetweenDate(LocalDateTime.of(1964, 1, 2, 1, 1),
				LocalDateTime.of(1990, 1, 2, 1, 1));
		assertArrayEquals(expected, actual);
	}

	@Test
	void testSize() {
		assertEquals(5, album.size());
	}

}
