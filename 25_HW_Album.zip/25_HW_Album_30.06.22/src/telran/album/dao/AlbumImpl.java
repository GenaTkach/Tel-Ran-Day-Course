package telran.album.dao;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Comparator;

import telran.album.interfaces.Album;
import telran.album.model.Photo;

public class AlbumImpl implements Album {
	Photo[] photos;
	int size;

	public AlbumImpl(int capacity) {
		photos = new Photo[capacity];
	}

	@Override
	public boolean addPhoto(Photo photo) {
		if (photo == null || size >= photos.length
				|| getPhotoFromAlbum(photo.getPhotoId(), photo.getAlbumId()) != null) {
			return false;
		}
		photos[size++] = photo;
		return true;
	}

	@Override
	public boolean removePhoto(int photoId, int albumId) {
		for (int i = 0; i < size; i++) {
			if (getPhotoFromAlbum(photoId, albumId) != null) {
				photos[i] = null;
				for (int j = i; j < size - 1; j++) {
					photos[j] = photos[j + 1];
				}
				size--;
				return true;
			}
		}
		return false;

	}

	@Override
	public boolean updatePhoto(int photoId, int albumId, String url) {
		for (int i = 0; i < size; i++) {
			if (getPhotoFromAlbum(photoId, albumId) != null) {
				photos[i].setUrl(url);
				return true;
			}
		}
		return false;
	}

	@Override
	public Photo getPhotoFromAlbum(int photoId, int albumId) {
		for (int i = 0; i < size; i++) {
			if (photos[i].getAlbumId() == albumId && photos[i].getPhotoId() == photoId) {
				return photos[i];
			}
		}
		return null;
	}

	@Override
	public Photo[] getAllPhotoFromAlbum(int albumId) {
		int sizeOfArr = 0;
		for (int i = 0; i < size; i++) {
			if (photos[i].getAlbumId() == albumId) {
				sizeOfArr++;
			}
		}

		Photo[] newArr = new Photo[sizeOfArr];
		for (int i = 0, j = 0; i < size; i++) {
			if (photos[i].getAlbumId() == albumId) {
				newArr[j++] = photos[i];
			}
		}
		return newArr;
	}

	@Override
	public Photo[] getPhotoBetweenDate(LocalDateTime dateFrom, LocalDateTime dateTo) {
		int from = 0;
		int upto = size;
		for (int i = 0; i < size; i++) {
			if (photos[i].getDate().isAfter(dateFrom)) {
				from = i;
				break;
			}
		}
		
		for (int j = from + 1; j < size; j++) {
			if (photos[j].getDate().isAfter(dateTo)) {
				upto = j - 1;
				break;
			}
		}

		Photo[] newArr = Arrays.copyOfRange(photos, from, upto);
		return newArr;
	}

	@Override
	public int size() {
		return size;
	}

}
