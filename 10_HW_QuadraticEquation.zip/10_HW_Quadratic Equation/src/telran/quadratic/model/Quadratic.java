package telran.quadratic.model;

public class Quadratic {
	private double a;
	private double b;
	private double c;

	// Constructor
	public Quadratic(double a, double b, double c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}

	public double[] displaySolution() {
		double d = discriminant();
		if (d == 0) {
			double[] x = { -b / 2 * a };
			return x;
		} else if (d > 0) {
			double[] x = new double[2];
			x[0] = (-b + Math.sqrt(d)) / (2 * a);
			x[1] = (-b - Math.sqrt(d)) / (2 * a);
			return x;
		} else {
			double[] x = new double[0];
			return x;
		}
	}

	public double discriminant() {
		double d = b * b - 4 * a * c;
		return d;
	}

	public void isEqual() {
		double[] x = displaySolution();
		if (x.length > 0) {
			System.out.println("True. Both sides of the equation are equal.");
		} else {
			System.out.println("False. There is no equality.");
		}
	}

	public void howManySolutions() {
		double[] x = displaySolution();
		if (x.length != 1) {
			System.out.println("There is " + x.length + " solutions.");
		} else {
			System.out.println("There is only " + x.length + " solution.");
		}
	}
}
