package telran.quadratic.controller;

import telran.quadratic.model.Quadratic;

public class QuadraticApp {

	public static void main(String[] args) {
		//Initialization prototype of a class
		Quadratic first = new Quadratic(3, -6, 0);

		//Output solutions
		double[] d = first.displaySolution();
		for (int i = 0; i < d.length; i++) {
			System.out.println("x: " + d[i]);
		}
		
		//Check for equality
		first.isEqual();
		
		//Finding amount of solutions
		int res = first.howManySolutions();
		System.out.println("Amount of solutions : " + res);
	}
}
