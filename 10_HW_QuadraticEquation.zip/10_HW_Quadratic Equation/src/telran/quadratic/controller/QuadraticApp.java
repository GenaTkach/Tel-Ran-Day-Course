package telran.quadratic.controller;

import telran.quadratic.model.Quadratic;

public class QuadraticApp {

	public static void main(String[] args) {
		Quadratic first = new Quadratic(1, -6, 9);

		double[] d = first.displaySolution();
		for (int i = 0; i < d.length; i++) {
			System.out.println("x: " + d[i]);
		}
		
		first.isEqual();
		first.howManySolutions();
	}
}
