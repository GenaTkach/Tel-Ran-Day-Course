package telran.validator.tools;

public class Validator {
	public static boolean checkCreditCard(String number) {
		String pattern = "\\d{8,16}";
		return number.matches(pattern);
	}
	
	//Format: DD.MM.YYYY
	public static boolean checkDateFormatEU(String number) {
		String pattern = "[0-3][0-9]\\.[0-1][0-9]\\.\\d{4}";
		return number.matches(pattern);
	}
	
	//Format: YYYY-MM-DD
	public static boolean checkDateFormatUS(String number) {
		String pattern = "\\d{4}-[0-1][0-9]-[0-3][0-9]";
		return number.matches(pattern);
	}
	
	//Format: +99(99)9999-9999
	public static boolean checkPhoneNumber(String number) {
		String pattern = "\\+\\d{2}\\(\\d{2}\\)\\d{4}-\\d{4}";
		return number.matches(pattern);
	}
	
	//Number less and equals 255
	public static boolean checkLessEquals255(String number) {
		String pattern = "[0-2]{1}[0-9]?[0-5]?";
		return number.matches(pattern);
	}
}
