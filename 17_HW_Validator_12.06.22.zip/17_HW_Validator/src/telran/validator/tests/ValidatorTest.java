package telran.validator.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import telran.validator.tools.Validator;

class ValidatorTest {

	@Test
	void testCheckCreditCard() {
		assertTrue(Validator.checkCreditCard("12345678"));
		assertTrue(Validator.checkCreditCard("1234567890"));
		assertTrue(Validator.checkCreditCard("1234567890987654"));
		assertFalse(Validator.checkCreditCard("1234567"));
		assertFalse(Validator.checkCreditCard("12345678909876543"));
		assertFalse(Validator.checkCreditCard("1234567a89098765"));
	}

	@Test
	void testCheckDateFormatEU() {
		assertTrue(Validator.checkDateFormatEU("12.08.2004"));
		assertTrue(Validator.checkDateFormatEU("29.10.2256"));
		assertTrue(Validator.checkDateFormatEU("31.05.1994"));
		assertFalse(Validator.checkDateFormatEU("12.3.4.5672"));
		assertFalse(Validator.checkDateFormatEU("1234.5672"));
		assertFalse(Validator.checkDateFormatEU("42.14.5672"));
	}

	@Test
	void testCheckDateFormatUS() {
		assertTrue(Validator.checkDateFormatUS("2004-08-12"));
		assertTrue(Validator.checkDateFormatUS("1324-12-01"));
		assertTrue(Validator.checkDateFormatUS("1994-05-23"));
		assertFalse(Validator.checkDateFormatUS("1994.05.23"));
		assertFalse(Validator.checkDateFormatUS("1234-23-08"));
		assertFalse(Validator.checkDateFormatUS("12345-05-23"));
	}

	@Test
	void testCheckPhoneNumber() {
		assertTrue(Validator.checkPhoneNumber("+12(23)1111-2345"));
		assertTrue(Validator.checkPhoneNumber("+22(39)7235-9658"));
		assertFalse(Validator.checkPhoneNumber("-22(39)7235-9658"));
		assertFalse(Validator.checkPhoneNumber("+22(339)7235-9658"));
		assertFalse(Validator.checkPhoneNumber("+22(339)72359658"));
	}

	@Test
	void testCheckLessEquals255() {
		assertTrue(Validator.checkLessEquals255("255"));
		assertTrue(Validator.checkLessEquals255("25"));
		assertTrue(Validator.checkLessEquals255("2"));
		assertTrue(Validator.checkLessEquals255("254"));
		assertFalse(Validator.checkLessEquals255("256"));
		assertFalse(Validator.checkLessEquals255("-1"));
		assertFalse(Validator.checkLessEquals255("2561"));

	}

}
