package telran.list.model;

import java.util.Iterator;

import telran.list.interfaces.IList;

public class MyLinkedList<E> implements IList<E> {
	private Node<E> first;
	private Node<E> last;
	private int size;
	
	//O(n)
	@Override
	public Iterator<E> iterator() {
		return new Iterator<E>() {
			int i;
			
			@Override
			public boolean hasNext() {
				return i < size;
			}

			@Override
			public E next() {
				return get(i++);
			}
		};
	}
	
	//O(1)
	@Override
	public boolean add(E element) {
		Node<E> newNode = new Node<E>(last, element, null);
		if (last != null) {
			last.next = newNode;
		} else {
			first = newNode;
		}
		last = newNode;
		size++;
		return true;
	}

	//O(n)
	@Override
	public void clear() {
		for (int i = 0; i < size;) {
			remove(i);
		}
	}

	//O(1)
	@Override
	public int size() {
		return size;
	}

	//O(1)
	@Override
	public boolean add(int index, E element) {
		checkIndex(index);
		Node<E> node = getNodeByIndex(index);
		Node<E> prev = node.prev;
		Node<E> newNode = new Node<E>(prev, element, node);
		
		if(index != 0 && index != size) {
			node.prev = newNode;
			newNode.next = node;
			
			newNode.prev = prev;
			prev.next = newNode;
		} else if(index == 0) {
			node.prev = newNode;
			newNode.next = node;

//Question. Нужна ли строка номер 72? или когда мы назначаем first, то его prev не нужно указывать на null?
			newNode.prev = null;
			first = newNode;
		} else if(index == size) {
			add(element);
		}
		size++;
		return true;
	}
	
	//O(n)
	@Override
	public E get(int index) {
		Node<E> node = getNodeByIndex(index);
		return node.data;
	}
	
	//Optimize it
	private Node<E> getNodeByIndex(int index) {
		checkIndex(index);
		
		Node<E> node;
		if (index <= size / 2) {
			node = first;
			for (int i = 0; i < index; i++) {
				node = node.next;
			} 
		} else {
			node = last;
			for (int i = size; i > index + 1; i--) {
				node = node.prev;
			}
		}
		return node;
	}

	private void checkIndex(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException(index);
		}
	}

	//O(n)
	@Override
	public int indexOf(Object o) {
		int index = 0;
		if (o != null) {
			for (Node<E> x = first; index < size; x = x.next, index++) {
				if (o.equals(x.data)) {
					return index;
				}
			}
		} else {
			for (Node<E> x = first; index < size; x = x.next, index++) {
				if (o == x.data) {
					return index;
				}
			}
		}
		return -1;
	}
	
	//O(n)
	@Override
	public int lastIndexOf(Object o) {
		int index = size - 1;
		if (o != null) {
			for (Node<E> x = last; x != null; x = x.prev, index--) {
				if (o.equals(x.data)) {
					return index;
				}
			}
		} else {
			for (Node<E> x = last; x != null; x = x.prev, index--) {
				if (o == x.data) {
					return index;
				}
			}
		}
		return -1;
	}
	
	//O(n)
	@Override
	public E remove(int index) {
		Node<E> node = getNodeByIndex(index);
		return unlink(node);
	}

	private E unlink(Node<E> node) {
		E removed = node.data;
		Node<E> prev = node.prev;
		Node<E> next = node.next;
		
		//Condition for first
		if (prev != null) {
			prev.next = next;
			node.prev = null;
		} else {
			first = next;
		}
		
		//Condition for last
		if (next != null) {
			next.prev = prev;
			node.next = null;
		} else {
			last = prev;
		}
		
		node.data = null;
		size--;
		return removed;
	}
	
	//O(n)
	@Override
	public E set(int index, E element) {
		Node<E> node = getNodeByIndex(index);
		E removed = node.data;
		node.data = element;
		return removed;
	}
	
	//Anonymous class
	private static class Node<E> {
		Node<E> prev;
		E data;
		Node<E> next;
		
		public Node(Node<E> prev, E data, Node<E> next) {
			this.prev = prev;
			this.data = data;
			this.next = next;
		}

	}

}


