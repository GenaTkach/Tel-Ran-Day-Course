package telran.array.tools;

import java.util.Arrays;

public class MemoryService {
	public static int getMaxArrayMemory() {
		
		int[] arr;
		int right = Integer.MAX_VALUE;
		int center;
		int left = 0;

		while(left + 1 != right) {
			center = (left + right) / 2;
			try {
				arr = new int[center];
				left = center; 
			} catch (OutOfMemoryError e) {
				right = center;
			}
		}
		return left;
	}
}