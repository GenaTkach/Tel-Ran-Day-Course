package telran.arrays.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import telran.arrays.tools.ArrayTools;

class ArraysTest {
	Integer[] arrNum;
	String[] arrStr;

	@BeforeEach
	void setUp() throws Exception {
		arrNum = new Integer[] { 9, 4, 3, 2, 7, 0 };
		arrStr = new String[] { "One", "Two", "Three", "Four" };
	}

	@Test
	void testPrintArray() {
		System.out.println("Test printArray :");
		ArrayTools.printArray(arrNum);
		ArrayTools.printArray(arrStr);
	}

	@Test
	void testFindFirst() {
		System.out.println("Test findFirst :");
		Integer resInt = ArrayTools.findFirst(arrNum, n -> n % 2 == 0);
		System.out.println(resInt);
		String resStr = ArrayTools.findFirst(arrStr, s -> s.length() == 4);
		System.out.println(resStr);
	}

	@Test
	void testBubbleSortInteger() {
		System.out.println("Test BubbleSortInteger :");
		ArrayTools.bubbleSort(arrNum);
		ArrayTools.printArray(arrNum);
	}

	@Test
	void testBubbleSortString() {
		System.out.println("Test BubbleSortString :");
		ArrayTools.bubbleSort(arrStr);
		ArrayTools.printArray(arrStr);
	}

	@Test
	void testBubbleSortStringComparator() {
		System.out.println("Test BubbleSortString Comparator :");
		ArrayTools.bubbleSort(arrStr, (s1, s2) -> s1.length() - s2.length());
		ArrayTools.printArray(arrStr);
		// TODO comparator that sorts array. At first even numbers in increasing order,
		// than odd numbers in decreasing order
		System.out.println("Test BubbleSortString Comparator for integers :");
		ArrayTools.bubbleSort(arrNum, (i1, i2) -> {
			if (((i1 - i2) % 2 == 0) && (i1.compareTo(i2) > 0) && (i1 % 2 == 0)) return 1;
			else if (((i1 - i2) % 2 == 0) && (i1.compareTo(i2) < 0) && (i1 % 2 == 0)) return 0;
			else if (((i1 - i2) % 2 == 0) && (i1.compareTo(i2) < 0) && (i1 % 2 != 0)) return 1;
			else if (((i1 - i2) % 2 == 0) && (i1.compareTo(i2) > 0) && (i1 % 2 != 0)) return 0;
			else if (((i1 - i2) % 2 != 0) && (i1 % 2 == 0)) return 0;
			else if (((i1 - i2) % 2 != 0) && (i1 % 2 != 0)) return 1;
			else return -1;
			});
		ArrayTools.printArray(arrNum);
	}
}
