package telran.regex.tools;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PhotoSelector {
	public static String[] selectPictures(String[] pictures, String regex) {
		int size = 0;
		for (int i = 0; i < pictures.length; i++) {
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(pictures[i]);
			if (matcher.find()) {
				size++;
			}
		}
		
		String[] arr = new String[size];
		for (int i = 0; i < arr.length; i++) {
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(pictures[i]);
			if (matcher.find()) {
				arr[i] = pictures[i];
			}
		}
		return arr;
	}
}
