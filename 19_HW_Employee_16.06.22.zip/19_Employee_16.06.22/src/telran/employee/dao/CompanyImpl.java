package telran.employee.dao;

import telran.employee.model.Employee;
import telran.employee.model.SalesManager;

public class CompanyImpl implements Company {
	// Fields
	Employee[] employees;
	int size = 0;

	public CompanyImpl(int capacity) {
		employees = new Employee[capacity];
	}

	@Override
	public boolean addEmployee(Employee employee) {
		if (getSize() < employees.length) {
			// Check for duplicates
			for (int i = 0; i < employees.length; i++) {
				if (employees[i] == employee) {
					return false;
				}
			}
			for (int i = 0; i < employees.length; i++) {
				if (employees[i] == null) {
					employees[i] = employee;
					size++;
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public Employee removeEmployee(int id) {
		if (getSize() > 0) {
			for (int i = 0; i < employees.length; i++) {
				if (employees[i] != null && employees[i].getId() == id) {
					size--;
					return employees[i];
				}
			}
		}
		return null;
	}

	@Override
	public Employee findEmployee(int id) {
		for (int i = 0; i < employees.length; i++) {
			if (employees[i] != null && employees[i].getId() == id) {
				return employees[i];
			}
		}
		return null;
	}

	@Override
	public double totalSalary() {
		double total = 0;
		for (int i = 0; i < employees.length; i++) {
			if (employees[i] != null) {
				total += employees[i].calcSalary();
			}
		}
		return total;
	}

	@Override
	public double averageSalary() {
		double total = 0;
		for (int i = 0; i < employees.length; i++) {
			if (employees[i] != null) {
				total += employees[i].calcSalary();
			}
		}
		return total / size;
	}

	@Override
	public double totalSales() {
		double total = 0;
		for (int i = 0; i < employees.length; i++) {
			if (employees[i] != null && employees[i] instanceof SalesManager) {
				total += ((SalesManager) employees[i]).getSalesValue();
			}
		}
		return total;
	}

	@Override
	public int getSize() {
		return size;
	}

	@Override
	public boolean printEmployees() {
		boolean res = false;
		for (int i = 0; i < getSize(); i++) {
			if (employees[i] != null) {
				System.out.println(employees[i]);
				res = true;
			}
		}
		return res;
	}
}