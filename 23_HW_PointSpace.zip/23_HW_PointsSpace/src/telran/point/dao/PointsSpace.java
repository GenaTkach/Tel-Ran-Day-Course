package telran.point.dao;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Comparator;

import telran.point.model.Point;

public class PointsSpace {
	Point relPoint;
	Point[] points;
	Comparator<Point> comp = (p1, p2) -> {
		if (makePow(p1) > makePow(p2)) {
			return 1;
		} else if (makePow(p1) < makePow(p2)) {
			return -1;
		} else {
			return 0;
		}
	};

	Comparator<Point> compReverse = (p1, p2) -> {
		if (makePow(p1) > makePow(p2)) {
			return -1;
		} else if (makePow(p1) < makePow(p2)) {
			return 1;
		} else {
			return 0;
		}
	};
	
	private double makePow(Point point) {
		return (Math.pow(point.getX(), 2) + Math.pow(point.getY(), 2));
	}
	
	public PointsSpace(Point relPoint, Point[] points) {
		this.relPoint = relPoint;
		// FIXME Fix problem
		// TODO sort this.points by proximity to relPoint (ask to Pithagoras)
		// to apply method sort of class Arrays
		this.points = points;
		sortPoints(points);
	}

	private void sortPoints(Point[] points) {
		if (makePow(relPoint) < makePow(points[1])) {
			Arrays.sort(points, comp);
		} else {
			Arrays.sort(points, compReverse);
		}
	}

	public Point[] getPoints() {
		return points;
	}

	public void addPoint(Point point) {
		int index = Arrays.binarySearch(points, point, comp);
		Point[] newArray = new Point[points.length + 1];
		System.arraycopy(points, 0, newArray, 0, Math.abs(index));
		newArray[Math.abs(index)] = point;
		System.arraycopy(points, Math.abs(index), newArray, Math.abs(index) + 1, points.length - Math.abs(index));
		this.points = newArray;
		// TODO keep sort of this.points
		// to apply BinarySearch method of the class Arrays
		// to apply method arrayCopy of the class System
		// method arrayCopy will be called twice
	}

}
