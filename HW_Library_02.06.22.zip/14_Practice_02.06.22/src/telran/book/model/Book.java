package telran.book.model;

public class Book {
	// isbn(The International Standard Book Number), title, author,yearOfPublishing
	private String isbn = "-----------------";
	private String title;
	private String author;
	private int yearOfPublishing;

	// Constructor 1
	public Book(String isbn, String author, String title, int yearOfPublishing) {
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.yearOfPublishing = yearOfPublishing;
	}

	// Constructor 2
	public Book(String author, String title, int yearOfPublishing) {
		this.title = title;
		this.author = author;
		this.yearOfPublishing = yearOfPublishing;
	}

	// Constructor 3
	public Book(String author, String title) {
		this.title = title;
		this.author = author;
	}

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", author=" + author + ", yearOfPublishing="
				+ yearOfPublishing + "]";
	}

	public String getIsbn() {
		return isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getAuthor() {
		return author;
	}

	public int getYearOfPublishing() {
		return yearOfPublishing;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((isbn == null) ? 0 : isbn.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Book)) {
			return false;
		}
		Book other = (Book) obj;
		if (isbn == null) {
			if (other.isbn != null) {
				return false;
			}
		} else if (!isbn.equals(other.isbn)) {
			return false;
		}
		return true;
	}

}
