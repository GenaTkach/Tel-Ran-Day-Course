package telran.book.dao;
//data access objects

//CRUD
//Create
//Read
//Update
//Delete

import telran.book.model.Book;

public class Library {
	private Book[] books;
	private int amountOfBooks;

	// Constructor
	public Library(int capacity) {
		books = new Book[capacity];
	}

	public boolean addBook(Book book) {
		if (books.length == amountOfBooks) {
			return false;
		}
		books[amountOfBooks++] = book; // books[amountOfBooks] = book; amountOfBooks++;
		return true;
	}

	public Book removeBookByTitle(String title) {
		if (helper(title) != -1) {
			Book victim = books[helper(title)];
			books[helper(title)] = books[amountOfBooks - 1];
			books[amountOfBooks - 1] = null;
			amountOfBooks--;
			return victim;
		}
		return null;
	}

	public Book findBookByTitle(String title) {
		if (helper(title) == -1) {
			return null;
		} else {
			return books[helper(title)];
		}
	}

	private int helper(String title) {
		for (int i = 0; i < amountOfBooks; i++) {
			if (title.equals(books[i].getTitle())) {
				return i;
			}
		}
		return -1;
	}

	public Book updateBook(String author, String newAuthor) {
		for (int i = 0; i < amountOfBooks; i++) {
			if (author.equals(books[i].getAuthor())) {
				books[i].setAuthor(newAuthor);
				return books[i];
			}
		}
		return null;
	}

	public void printBooks() {
		for (int i = 0; i < amountOfBooks; i++) {
			System.out.println(books[i]);
		}
	}

	public int getAmountOfBooks() {
		return amountOfBooks;
	}

	// HoneWork
	public void printAllBooksFromYear(int from) {
		for (int i = 0; i < amountOfBooks; i++) {
			if (books[i].getYearOfPublishing() >= from) {
				System.out.println(books[i]);
			}
		}
	}

	public void printAllBooksFromUpToYears(int from, int upto) {
		for (int i = 0; i < amountOfBooks; i++) {
			if (books[i].getYearOfPublishing() >= from && books[i].getYearOfPublishing() <= upto) {
				System.out.println(books[i]);
			}
		}
	}

	public void printAllBooksFromThisAuthor(String author) {
		for (int i = 0; i < amountOfBooks; i++) {
			if (books[i].getAuthor().equals(author)) {
				System.out.println(books[i]);
			}
		}
	}
}
