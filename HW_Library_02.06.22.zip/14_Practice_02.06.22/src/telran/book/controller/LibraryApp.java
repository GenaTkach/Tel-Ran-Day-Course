package telran.book.controller;

import telran.book.dao.Library;
import telran.book.model.Book;

public class LibraryApp {

	public static void main(String[] args) {
		Library lib = new Library(8);
		lib.addBook(new Book("978-0-224-10215-5", "Irvine Welsh", "The Blade Artist", 2016));
		lib.addBook(new Book("000-0-375-70402-7","Haruki Murakami", "Norwegian Wood", 1987));
		lib.addBook(new Book("Liu Cixin", "The Three-Body Problem", 2006));
		lib.addBook(new Book("978-0-063-00204-3","Hanna Richell", "The River Home", 2020));
		lib.addBook(new Book("0-02-615170-7","Arkady and Boris Strugatsky", "Roadside Picnic", 1972));
		lib.addBook(new Book("0-307-26919-1","Haruki Murakami", "What I Talk About When I Talk About Running", 2008));

		lib.printBooks();
		lib.addBook(new Book("978-0-224-10215-6", "Irvine Welsh", "Glue", 1993));
		System.out.println("=========================================");
		System.out.println("!Adding book!");
		lib.printBooks();
		System.out.println("=========================================");
		System.out.println("!Get amount of books!");
		System.out.println(lib.getAmountOfBooks());
		System.out.println("=========================================");
		System.out.println("!Print all books from 2000 year!");
		lib.printAllBooksFromYear(2000);
		System.out.println("=========================================");
		System.out.println("!Print all books from 1970 year upto 1998!");
		lib.printAllBooksFromUpToYears(1970, 1998);
		System.out.println("=========================================");
		System.out.println("!Print all books by Haruki Murakami!");
		lib.printAllBooksFromThisAuthor("Haruki Murakami");
		System.out.println("=========================================");
		System.out.println("!Find book by title!");
		System.out.println(lib.findBookByTitle("Norwegian Wood"));
		System.out.println("=========================================");
		System.out.println("!Update book!");
		System.out.println(lib.updateBook("Irvine Welsh", "Chak Palanik"));
	}
}