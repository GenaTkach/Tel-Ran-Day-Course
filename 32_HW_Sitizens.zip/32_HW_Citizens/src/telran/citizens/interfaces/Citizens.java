package telran.citizens.interfaces;

import telran.citizens.model.Person;

public interface Citizens {
	boolean add(Person person);

	boolean remove(Person person);

	Person find(int id);

	Iterable<Person> find(int minAge, int maxAge);

	Iterable<Person> find(String lastName);

	Iterable<Person> getAllPersonSortedById();

	Iterable<Person> getAllPersonSortedByAge();

	Iterable<Person> getAllPersonSortedByLastName();

	int size();
}
