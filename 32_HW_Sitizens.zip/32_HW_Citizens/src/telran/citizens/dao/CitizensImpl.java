package telran.citizens.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import telran.citizens.interfaces.Citizens;
import telran.citizens.model.Person;

public class CitizensImpl implements Citizens {
	private List<Person> idList;
	private List<Person> lastNameList;
	private List<Person> ageList;
	private static Comparator<Person> lastNameComparator = (o1, o2) -> o1.getLastName()
			.compareToIgnoreCase(o2.getLastName());
	private static Comparator<Person> ageComparator = (o1, o2) -> o1.getAge() - o2.getAge();

	public CitizensImpl() {
		idList = new ArrayList<Person>();
		lastNameList = new ArrayList<Person>();
		ageList = new ArrayList<Person>();
	}

	public CitizensImpl(List<Person> citizens) {
//		// Переложить в пустые листы новый лист citizens, так чтобы не было дубликатов
//		// по id и чтобы они были отсортированны.
		
		//Check and remove dublicates
		for (int i = 0; i < citizens.size() - 1; i++) {
			for (int j = citizens.size() - 1; j > i; j--) {
				if (citizens.get(j).getId() == citizens.get(i).getId()) {
					citizens.remove(j);
				}
			}
		}
		//Adding citizens list ot our empty lists
		idList.addAll(citizens);
		lastNameList.addAll(citizens);
		ageList.addAll(citizens);
		// Sorting
		Collections.sort(idList);
		Collections.sort(lastNameList, lastNameComparator);
		Collections.sort(ageList, ageComparator);
	}

	@Override
	public boolean add(Person person) {
		if (person == null || find(person.getId()) != null) {
			return false;
		}
		if (size() == 0) {
			idList.add(person);
			lastNameList.add(person);
			ageList.add(person);
			return true;
		}
		int index = Collections.binarySearch(idList, person);
		index = index > 0 ? index : -index - 1;
		idList.add(index, person);

		index = Collections.binarySearch(lastNameList, person);
		index = index > 0 ? index : -index - 1;
		lastNameList.add(index, person);

		index = Collections.binarySearch(ageList, person);
		index = index > 0 ? index : -index - 1;
		ageList.add(index, person);

		return true;
	}

	@Override
	public boolean remove(Person person) {
		int index = Collections.binarySearch(idList, person);
		if (index > 0) {
			idList.remove(index);
			index = Collections.binarySearch(lastNameList, person);
			lastNameList.remove(index);
			index = Collections.binarySearch(ageList, person);
			ageList.remove(index);
			return true;
		}
		return false;
	}

	@Override
	public Person find(int id) {
		idList.iterator();
		for (Person person : idList) {
			if (person.getId() == id) {
				return person;
			}
		}
		return null;
	}

	@Override
	public Iterable<Person> find(int minAge, int maxAge) {
		return null;
	}

	@Override
	public Iterable<Person> find(String lastName) {
		return null;
	}

	@Override
	public Iterable<Person> getAllPersonSortedById() {
		return null;
	}

	@Override
	public Iterable<Person> getAllPersonSortedByAge() {
		return null;
	}

	@Override
	public Iterable<Person> getAllPersonSortedByLastName() {
		return null;
	}

	@Override
	public int size() {
		return idList.size();
	}

}
