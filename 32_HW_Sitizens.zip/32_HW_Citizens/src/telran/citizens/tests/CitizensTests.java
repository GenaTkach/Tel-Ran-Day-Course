package telran.citizens.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import telran.citizens.dao.CitizensImpl;
import telran.citizens.interfaces.Citizens;
import telran.citizens.model.Person;

class CitizensTests {
	Citizens citizens;

	@BeforeEach
	void setUp() throws Exception {
		citizens = new CitizensImpl(
				Arrays.asList(new Person(1, "Peter", "Jackson", 23), new Person(2, "Jonh", "Smith", 20),
						new Person(3, "Mary", "Jackson", 20), new Person(4, "Tigran", "Petrosyan", 25)));
	}

	@Test
	void testCitizensImplListOfPerson() {
		citizens = new CitizensImpl(Arrays.asList(new Person(1, "Peter", "Jackson", 23),
				new Person(2, "Jonh", "Smith", 20), new Person(2, "Jonh", "Smith", 20)));
		assertEquals(2, citizens.size());
	}

	@Test
	void testAdd() {
		assertFalse(citizens.add(new Person(1, "Peter", "Jackson", 23)));
		assertTrue(citizens.add(new Person(5, "Yuval", "Harari", 45)));
		assertEquals(5, citizens.size());
	}

	@Test
	void testRemove() {
		assertFalse(citizens.remove(new Person(5, "Yuval", "Harari", 45)));
		assertTrue(citizens.remove(new Person(1, "Peter", "Jackson", 23)));
		assertEquals(3, citizens.size());
	}

	@Test
	void testFindInt() {
		assertEquals(null, citizens.find(5));
		assertEquals(citizens.find(1), citizens.find(1));
	}

	@Test
	void testFindIntInt() {
		assertEquals(citizens.find(20, 22),
				Arrays.asList(new Person(2, "Jonh", "Smith", 20), new Person(3, "Mary", "Jackson", 20)));
	}

	@Test
	void testFindString() {
		assertEquals(citizens.find("Jackson"),
				Arrays.asList(new Person(1, "Peter", "Jackson", 23), new Person(3, "Mary", "Jackson", 20)));
	}

	@Test
	void testGetAllPersonSortedById() {
		assertEquals(
				Arrays.asList(new Person(1, "Peter", "Jackson", 23), new Person(2, "Jonh", "Smith", 20),
						new Person(3, "Mary", "Jackson", 20), new Person(4, "Tigran", "Petrosyan", 25)),
				citizens.getAllPersonSortedById());
	}

	@Test
	void testGetAllPersonSortedByAge() {
		assertEquals(
				Arrays.asList(new Person(2, "Jonh", "Smith", 20), new Person(3, "Mary", "Jackson", 20), new Person(1, "Peter", "Jackson", 23), new Person(4, "Tigran", "Petrosyan", 25)), citizens.getAllPersonSortedByAge());
	}

	@Test
	void testGetAllPersonSortedByLastName() {
		assertEquals(
				Arrays.asList(new Person(1, "Peter", "Jackson", 23), new Person(3, "Mary", "Jackson", 20),  new Person(4, "Tigran", "Petrosyan", 25), new Person(2, "Jonh", "Smith", 20)), citizens.getAllPersonSortedByLastName());
	}

	@Test
	void testSize() {
		assertEquals(4, citizens.size());
		assertTrue(citizens.remove(new Person(1, "Peter", "Jackson", 23)));
		assertEquals(3, citizens.size());
	}

}
