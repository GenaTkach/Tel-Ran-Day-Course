package telran.cars.dao;

import java.util.function.Predicate;

import telran.cars.interfaces.Garage;
import telran.cars.model.Car;

public class GarageImpl implements Garage {
	Car[] garage;
	int size;

	public GarageImpl(int capacity) {
		garage = new Car[capacity];
	}

	@Override
	public boolean addCar(Car car) {
		if (car == null || size == garage.length || findCarByRegNumber(car.getRegNumber()) != null) {
			return false;
		}
		garage[size] = car;
		size++;
		return true;
	}

	@Override
	public Car removeCar(String regNumber) {
		Car temp;
		for (int i = 0; i < size; i++) {
			if (garage[i].getRegNumber().equals(regNumber)) {
				temp = garage[i];
				garage[i] = garage[size--];
				garage[size] = null;
				return temp;
			}
		}
		return null;
	}

	@Override
	public Car findCarByRegNumber(String regNumber) {
		Car temp;
		for (int i = 0; i < size; i++) {
			if (garage[i].getRegNumber().equals(regNumber)) {
				temp = garage[i];
				return temp;
			}
		}
		return null;
	}

	@Override
	public Car[] findCarsByModel(String model) {
		return findCarsByPredicate(c -> c.getModel().equals(model));
	}

	@Override
	public Car[] findCarsByCompany(String company) {
		return findCarsByPredicate(c -> c.getCompany().equals(company));
	}

	@Override
	public Car[] findCarsByEngine(double min, double max) {
		return findCarsByPredicate(c -> c.getEngine() >= min && c.getEngine() < max);
	}

	@Override
	public Car[] findCarsByColor(String color) {
		return findCarsByPredicate(c -> c.getColor().equals(color));
	}

	public Car[] findCarsByPredicate(Predicate<Car> condition) {
		int count = 0;
		for (int i = 0; i < size; i++) {
			if (condition.test(garage[i])) {
				count++;
			}
		}
		Car[] newCars = new Car[count];
		for (int i = 0, j = 0; j < newCars.length; i++) {
			if (condition.test(garage[i])) {
				newCars[j++] = garage[i];
			}
		}
		return newCars;
	}

	public int getSize() {
		return size;
	}

}
