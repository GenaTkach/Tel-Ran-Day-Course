package telran.cars.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import telran.cars.dao.GarageImpl;
import telran.cars.interfaces.Garage;
import telran.cars.model.Car;

class GarageTest {
	Garage garage;
	Car[] cars;
	
	
	@BeforeEach
	void setUp() throws Exception {
		garage = new GarageImpl(5);
		cars = new Car[4];
		cars[0] = new Car("101", "Toyota", "Crown", 2.5, "Black");
		cars[1] = new Car("202", "Hyundai", "Sonata", 2.0, "Silver");
		cars[2] = new Car("303", "Nissan", "Silvia", 3.5, "White");
		cars[3] = new Car("404", "Toyota", "Land cruiser", 5.6, "White");
		for (int i = 0; i < cars.length; i++) {
			garage.addCar(cars[i]);
		}
	}

	@Test
	void testAddCar() {
		Car newCar = new Car("505", "Suzuki", "Swift", 1.8, "Black");
		assertTrue(garage.addCar(newCar));
		newCar = new Car("606", "Honda", "Civic", 1.8, "Purple");
		assertFalse(garage.addCar(newCar));
		assertEquals(5, garage.getSize());
	}

	@Test
	void testRemoveCar() {
		Car actual = garage.removeCar("202");
		Car expected = cars[1];
		assertEquals(expected, actual);
	}

	@Test
	void testFindCarByRegNumber() {
		Car actual = garage.findCarByRegNumber("101");
		Car expected = cars[0];
		assertEquals(expected, actual);
	}

	@Test
	void testFindCarsByModel() {
		Car newCar = new Car("909", "Toyota", "Crown", 3.5, "White");
		garage.addCar(newCar);
		assertEquals(5, garage.getSize());
		Car[] actual = garage.findCarsByModel("Sonata");
		Car[] expected = {cars[1]};
		assertArrayEquals(expected, actual);
//		Car[] actual = garage.findCarsByModel("Crown");
//		Car[] expected = {cars[0], cars[4]};
//		assertArrayEquals(expected, actual);
	}

	@Test
	void testFindCarsByCompany() {
		Car[] actual = garage.findCarsByCompany("Toyota");
 		Car[] expected = {cars[0], cars[3]};
 		assertArrayEquals(expected, actual);
 	}

	@Test
	void testFindCarsByEngine() {
		Car[] actual = garage.findCarsByEngine(2.0, 3.0);
		Car[] expected = {cars[0], cars[1]};
		assertArrayEquals(expected, actual);
	}

	@Test
	void testFindCarsByColor() {
		Car[] actual = garage.findCarsByColor("White");
		Car[] expected = {cars[2], cars[3]};
		assertArrayEquals(expected, actual);
	}

}
