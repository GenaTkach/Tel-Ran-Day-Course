package telran.list.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import telran.list.interfaces.IList;
import telran.list.model.MyArrayList;

class ListTests {

	@Test
	void test() {
		IList<Integer> list = new MyArrayList<Integer>();

		System.out.println(list.size());
		list.add(2);
		list.add(7);
		list.add(3);
		list.add(3);
		list.add(null);
		list.add(3);
		System.out.println(list.size());

		System.out.println(list.get(4));

		System.out.println(list.indexOf(null));

		System.out.println(list.contains(2));

		System.out.println(list.isEmpty());

		System.out.println("Remove number 7. Is it done? = " + list.remove((Integer) 7));
		System.out.println(list.contains(7));
		
		System.out.println("Remove number in index 0. What was in this index? = " + list.remove(0));
		
		list.set(3, 12);
		System.out.println(list.get(3));
		System.out.println(list.get(0));
		
		
		System.out.println("==============");
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
		System.out.println(list.lastIndexOf(3));
		
		
		System.out.println("======Iterator========");
		for (Integer integer : list) {
			System.out.println(integer);
		}
		
		System.out.println("======Method clear========");
		System.out.println("List size before clear = " + list.size());
		list.clear();
		System.out.println("List size after clear = " + list.size());
		
		System.out.println("======Method add element in index========");
		list.add(2);
		list.add(7);
		list.add(3);
		list.add(54);
		list.add(null);
		list.add(105);
		list.add(106);
		list.add(107);
		list.add(108);
		list.add(109);
		for (Integer integer : list) {
			System.out.println(integer);
		}
		System.out.println("Size before adding = " + list.size());
		list.add(7, 999999999);
		System.out.println("Size after adding = " + list.size());
		for (Integer integer : list) {
			System.out.println(integer);
		}
		
		}
	}

