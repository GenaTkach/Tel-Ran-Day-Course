package telran.fibonacci.controller;

import telran.fibonacci.model.Fibonacci;

public class FibonacciApp {

	public static void main(String[] args) {
		Fibonacci fibonacci = new Fibonacci(8);
		for (Integer num : fibonacci) {
			// TODO print all numbers 1, 1, 2, 3, 5, 8, 13, 21
			System.out.println(num);
		}
		
		int counter = 0;
		for (Integer num : fibonacci) {
			// TODO print sum of all numbers 1, 1, 2, 3, 5, 8, 13, 21
			counter += num;
		}
		System.out.println("Sum = " + counter);
	}

}
