package telran.fibonacci.model;

import java.util.Iterator;

public class Fibonacci implements Iterable<Integer>{
	private int quantity;

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Fibonacci(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public Iterator<Integer> iterator() {
		return new Iterator<Integer>() {
			private int currPos = 2;
			int left = 1;
			int right = 1;
			
			@Override
			public boolean hasNext() {
				return currPos < quantity;
			}

			@Override
			public Integer next() {
				Integer num = left + right;
				right = left;
				left = num;
				currPos++;
				return num;
			}
		};
	}
}
