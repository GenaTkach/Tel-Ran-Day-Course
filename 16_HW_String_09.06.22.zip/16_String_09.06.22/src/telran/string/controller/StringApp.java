package telran.string.controller;

public class StringApp {

	public static void main(String[] args) {
		String str = "Yo";
		str += " big";
		System.out.println(str);
		char[] chars = { ' ', 'w', 'o', 'r', 'l', 'd' };
		String str1 = new String(chars);
		System.out.println(str1);
		System.out.println("=========Methods=========");
		str += str1; //str.concat(str);
		System.out.println(str);
		System.out.println(str.length());
		char c = str.charAt(3);
		System.out.println(c);
		for (int i = 0; i < str.length(); i++) {
			System.out.println(str.charAt(i));
		}
		String str2 = " World";
		System.out.println(str1.equalsIgnoreCase(str2));
		String strUpper = str.toUpperCase();
		System.out.println(strUpper);
		int index = str.indexOf('o');
		System.out.println(index);
		index = str.lastIndexOf('o');
		System.out.println(index);
		System.out.println(str.substring(2, 5));
		System.out.println(str.replace("o", "o-o-o-o"));
	}

}
