package telran.user.controller;

import telran.user.model.User;

public class UserApp {

	public static void main(String[] args) {
		User user = new User("koby@gmail.com", "123456aA*");
		System.out.println(user);
		user.setEmail("ras@gm@ail.co.il");
		System.out.println(user);
		user.setPassword("123aaaaaaaa");
		System.out.println(user);
		user.setPassword("!12345678Aa");
		System.out.println(user);
	}

}
