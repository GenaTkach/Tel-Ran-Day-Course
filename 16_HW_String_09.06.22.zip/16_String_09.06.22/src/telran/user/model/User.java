package telran.user.model;

public class User {
	private String email;
	private String password;

	public User(String email, String password) {
		this.email = email;
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		if (validateEmail(email)) {
			this.email = email;
		} else {
			System.out.println(email + " is not valid");
		}
	}

	public void setPassword(String password) {
		if (validatePassword(password)) {
			this.password = password;
		} else {
			System.out.println(password + " is not valid");
		}
	}

	// 1) @ exists and only one
	// 2) dot after @
	// 3) after last dot minimum 2 symbols
	// 4) alphabetic, digits, _, -, ., @.
	private boolean validateEmail(String email) {
		int indexAt = email.indexOf("@");
		if (indexAt == -1 || indexAt != email.lastIndexOf("@")) {
			return false;
		}
		if (email.indexOf('.', indexAt + 1) < 0) {
			return false;
		}
		if (email.lastIndexOf('.') > email.length() - 3) {
			return false;
		}
		for (int i = 0; i < email.length(); i++) {
			if (!(Character.isAlphabetic(email.charAt(i)) || Character.isDigit(email.charAt(i))
					|| email.charAt(i) == '_' || email.charAt(i) == '.' || email.charAt(i) == '@')) {
				return false;
			}
		}
		return true;
	}

	/*
	 * 1) min 8 symbols 2) min one symbol in uppercase 3) min one symbol in
	 * lowercase 4) min one digit 5) min one special symbol (!%@*&)
	 * 
	 */
	private boolean validatePassword(String password) {
		if (password.length() < 8) {
			return false;
		}
		if (!(validateOtherParameters(password)))
			return false;
		return true;
	}

	private boolean validateOtherParameters(String password) {
		int up = 0;
		int low = 0;
		int digit = 0;
		int special = 0;
		for (int i = 0; i < password.length(); i++) {
			if (Character.isUpperCase(password.charAt(i))) {
				up++;
			}
			if (Character.isLowerCase(password.charAt(i))) {
				low++;
			}
			if (Character.isDigit(password.charAt(i))) {
				digit++;
			}
			if (password.charAt(i) == '!' || password.charAt(i) == '@' || password.charAt(i) == '%'
					|| password.charAt(i) == '&' || password.charAt(i) == '*') {
				special++;
			}
		}

		if (up > 0 && low > 0 && digit > 0 && special > 0) {
			return true;
		}
		return false;
	}

	public String getPassword() {
		return password;
	}

	@Override
	public String toString() {
		return "User [email=" + email + ", password=" + password + "]";
	}

}
