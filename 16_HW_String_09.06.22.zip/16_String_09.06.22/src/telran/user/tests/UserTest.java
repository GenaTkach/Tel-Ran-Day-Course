package telran.user.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import telran.user.model.User;

class UserTest {
	User user;
	String email = "koby@gmail.com";
	String password = "1234";

	@BeforeEach
	void setUp() throws Exception {
		user = new User(email, password);
	}

	@Test
	void testCorrectEmail() {
		user.setEmail("koby@yahoo.com");
		assertEquals("koby@yahoo.com", user.getEmail());
	}

	@Test
	void testWithoutAt() {
		user.setEmail("koby.yahoo.com");
		assertEquals(email, user.getEmail());
	}

	@Test
	void testManyAt() {
		user.setEmail("koby@yaho@o.com");
		assertEquals(email, user.getEmail());
	}

	@Test
	void testDotAfterAt() {
		user.setEmail("koby@yahoocom");
		assertEquals(email, user.getEmail());
	}

	@Test
	void testLastDot() {
		user.setEmail("koby@yahoo.co.m");
		assertEquals(email, user.getEmail());
		user.setEmail("koby@yahoo.com.");
		assertEquals(email, user.getEmail());
	}

	@Test
	void testIncorrectSymbol() {
		user.setEmail("ko!by@yahoo.com.");
		assertEquals(email, user.getEmail());
	}

	@Test
	void testCorrectPassword() {
		user.setPassword("123456aA*");
		assertEquals("123456aA*", user.getPassword());
	}

	@Test
	void testLessThanEightPassword() {
		user.setPassword("1256aA*");
		assertEquals(password, user.getPassword());
	}

	@Test
	void testNoDigits() {
		user.setPassword("aAaasddf*");
		assertEquals(password, user.getPassword());
	}

	@Test
	void testNoUpperCase() {
		user.setPassword("12345aaa*");
		assertEquals(password, user.getPassword());
	}

	@Test
	void testNoLowerCase() {
		user.setPassword("12345AAA*");
		assertEquals(password, user.getPassword());
	}

	@Test
	void testNoSpecialSymbol() {
		user.setPassword("12345aaaA");
		assertEquals(password, user.getPassword());
	}
}
