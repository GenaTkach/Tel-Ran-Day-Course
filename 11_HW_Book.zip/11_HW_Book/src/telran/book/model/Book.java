package telran.book.model;

public class Book {
	// isbn(The International Standard Book Number), title, author,yearOfPublishing
	private String isbn = "-----------------";
	private String title;
	private String author;
	private String yearOfPublishing = "Unknown";

	// Constructor 1
	public Book(String isbn, String author, String title, String yearOfPublishing) {
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.yearOfPublishing = yearOfPublishing;
	}

	// Constructor 2
	public Book(String author, String title, String yearOfPublishing) {
		this.title = title;
		this.author = author;
		this.yearOfPublishing = yearOfPublishing;
	}

	// Constructor 3
	public Book(String author, String title) {
		this.title = title;
		this.author = author;
	}

	public void display() {
		System.out.print("ISBN : " + isbn);
		System.out.print(" ,Author : " + author);
		System.out.print(" ,Title : " + title);
		System.out.print(" ,Year of publishing : " + yearOfPublishing);
		System.out.println();
	}
	
	public String getIsbn() {
		return isbn;
	}

	public String getTitle() {
		return title;
	}

	public String getAuthor() {
		return author;
	}

	public String getYearOfPublishing() {
		return yearOfPublishing;
	}

}
