package telran.book.controller;

import telran.book.model.Book;

public class BookApp {

	public static void main(String[] args) {
		Book[] book = new Book[3];
		book[0] = new Book("978-0-224-10215-5", "Irvine Welsh", "The Blade Artist", "2016");
		book[1] = new Book("Haruki Murakami", "Norwegian Wood", "1987");
		book[2] = new Book("Liu Cixin", "The Three-Body Problem");

		for (int i = 0; i < book.length; i++) {
			book[i].display();
		}

		System.out.println(
				"=========================================================================================================");
		for (int i = 0; i < book.length; i++) {
			if (book[i].getYearOfPublishing() != "Unknown") {
				book[i].display();
			}
		}

		System.out.println(
				"=========================================================================================================");
		for (int i = 0; i < book.length; i++) {
			if (book[i].getIsbn() != "-----------------") {
				book[i].display();
			}
		}

	}

}
