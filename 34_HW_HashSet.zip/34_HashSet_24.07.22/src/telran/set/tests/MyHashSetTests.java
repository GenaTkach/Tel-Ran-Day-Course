package telran.set.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import telran.set.model.ISet;
import telran.set.model.MyHashSet;

class MyHashSetTests {

	@Test
	void test() {
		ISet<String> mySet = new MyHashSet<>();
		System.out.println(mySet.size());
		mySet.add("Boston");
		mySet.add("Atlanta");
		mySet.add("Chicago");
		mySet.add("New york");
		mySet.add("Detroit");
		System.out.println("Size = " + mySet.size());
		System.out.println("==========Check duplicates========");
		mySet.add("Detroit");
		System.out.println("Size = " + mySet.size());
		System.out.println("Is there in list Chicago ? = " + mySet.contains("Chicago"));
		System.out.println("Is there in list Dallas ? = " + mySet.contains("Dallas"));
		System.out.println("==========Adding Dallas========");
		mySet.add("Dallas");
		System.out.println("Is there in list Dallas ? = " + mySet.contains("Dallas"));
		System.out.println("Size = " + mySet.size());
		System.out.println("==========Remove========");
		System.out.println("Was Chicago deleted ? = " + mySet.remove("Chicago"));
		System.out.println("Size after deleting ? = " + mySet.size());
		System.out.println("==========HW Iterator========");
		for (String string : mySet) {
			System.out.println(string);
		}
//		System.out.println("==========Adding some more cities========");
//		mySet.add("Tel Aviv");
//		mySet.add("Rishon leZion");
//		mySet.add("Ramat Gan");
//		mySet.add("Rehovot");
//		mySet.add("Nahariya");
//		System.out.println("==========Iterator========");
//		for (String string : mySet) {
//			System.out.println(string);
//		}
	}
}
