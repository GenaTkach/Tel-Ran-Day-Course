package telran.words.model;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class Anagram {
	public static boolean isAnagram(String word, String part) {
		/*
		 * 1. Подсчитать количество повторений букв в слове "electricity" и положить в Map.
		 * 2. Подсчитать количество букв в Part и положить в другой Map.
		 * 3. Пробежать по второму Map и если есть совпадение, то уменшить на единицу.
		 * 4. Получить коллекцию по значениям -> пробежать по ней. При условии, что хотя бы один элемент больше 0 -> return false.
		 */
		
		//Map for word "electricity"
		Map<String, Integer> map = new HashMap<>();
		String[] arr = word.split("");
		for (int i = 0; i < arr.length; i++) {
			map.merge(arr[i], 1, (a, b) -> a + b);	
		}
		
		//Map for part
		Map<String, Integer> mapForPart = new HashMap<>();
		String[] arrForPart = part.toLowerCase().split("");
		for (int i = 0; i < arrForPart.length; i++) {
			mapForPart.merge(arrForPart[i], 1, (a, b) -> a + b);
		}
		
		//Check if characters are present in second map.
		for (int i = 0; i < arr.length; i++) {
			mapForPart.computeIfPresent(arr[i], (k, v) -> v - 1);
		}
		
		//Making a collection of values and loop through this collection
		Collection<Integer> coll = mapForPart.values();
		for (Integer integer : coll) {
			if(integer > 0) {
				return false;
			}
		}
		return true;
	}
}
