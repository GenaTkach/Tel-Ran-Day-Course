package telran.collections.interfaces;

public interface Entity {
	
	public int getValue();// unique
	
}
