package telran.collections.interfaces;

public interface EntityCollection {
	
	public void add(Entity entity);
	public Entity removeMaxValue();
	
}
