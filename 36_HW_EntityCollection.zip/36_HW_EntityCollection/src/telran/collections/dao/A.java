package telran.collections.dao;

import java.util.HashSet;

import telran.collections.interfaces.Entity;
import telran.collections.interfaces.EntityCollection;

public class A implements EntityCollection {
	
	private HashSet<Entity> set = new HashSet<>();
	

	//O(1)
	@Override
	public void add(Entity entity) {
			set.add(entity);
	}
	
	//O(n)
	@SuppressWarnings("null")
	@Override
	public Entity removeMaxValue() {
		if (set.size() != 0) {
			Entity patternMax = null;
			for (Entity entity : set) {
				if(patternMax.getValue() < entity.getValue()) {
					patternMax = entity;
				}
			}
			set.remove(patternMax);
			return patternMax;
		}
		return null;
	}

}
