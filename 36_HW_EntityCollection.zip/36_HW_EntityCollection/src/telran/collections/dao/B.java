package telran.collections.dao;

import java.util.Comparator;
import java.util.TreeSet;

import telran.collections.interfaces.Entity;
import telran.collections.interfaces.EntityCollection;

public class B implements EntityCollection {

	private Comparator<Entity> comparator = ((e1, e2) -> e1.getValue() - e2.getValue());
	private TreeSet<Entity> set = new TreeSet<>(comparator);
	
	//O(log n)
	@Override
	public void add(Entity entity) {
		set.add(entity);
	}
	
	//O(1)
	@Override
	public Entity removeMaxValue() {
		return set.pollLast();
	}

}
