package telran.collections.dao;

import java.util.LinkedList;

import telran.collections.interfaces.Entity;
import telran.collections.interfaces.EntityCollection;

public class C implements EntityCollection {
	
	private LinkedList<Entity> list = new LinkedList<>();

	//O(n)
	@Override
	public void add(Entity entity) {
		if(!list.contains(entity)) {
			int count = 0;
			for (Entity elem : list) {
				if(elem.getValue() < entity.getValue()) {
					count++;
				}
			}
			list.add(count, entity);
		}
	}
	
	//O(1)
	@Override
	public Entity removeMaxValue() {
		Entity removed = list.getLast();
		list.pollLast();
		return removed;
	}

}
